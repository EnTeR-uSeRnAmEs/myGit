// MyKbMusic.cpp
#include "KbMIDI.h"

int main()
{
	kbMIDI("f1");
	return 0;
}
